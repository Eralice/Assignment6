package gui;
import java.awt.Color;



import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
//�̵���ҳ����
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;


import pojo.Pet;
import reader.PetDataReader;

@SuppressWarnings("serial")
public class BasePage extends JFrame {
	
	private PetDataReader pdr=new PetDataReader();
	private ArrayList<Pet> petlist=pdr.getList();//��ȡ�����б�

	
	private JButton back=new JButton("�˳�");
	
	//ʮ���ֳ�����Ʒ
	private JButton jb1=new JButton("����");
	private JButton jb2=new JButton("����");
	private JButton jb3=new JButton("����");
	private JButton jb4=new JButton("����");
	private JButton jb5=new JButton("����");
	private JButton jb6=new JButton("����");
	private JButton jb7=new JButton("����");
	private JButton jb8=new JButton("����");
	private JButton jb9=new JButton("����");
	private JButton jb10=new JButton("����");
	private JButton jb11=new JButton("����");
	private JButton jb12=new JButton("����");
	private JTextArea ja1=new JTextArea();
	private JTextArea ja2=new JTextArea();
	private JTextArea ja3=new JTextArea();
	private JTextArea ja4=new JTextArea();
	private JTextArea ja5=new JTextArea();
	private JTextArea ja6=new JTextArea();
	private JTextArea ja7=new JTextArea();
	private JTextArea ja8=new JTextArea();
	private JTextArea ja9=new JTextArea();
	private JTextArea ja10=new JTextArea();
	private JTextArea ja11=new JTextArea();
	private JTextArea ja12=new JTextArea();
	
	
	public BasePage(){
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setBounds(100, 100, 500, 500);
		setBackground(Color.gray);
		setLayout(null);//�����ɱ༭
		
	ja1.setBounds(12, 15, 100, 75);
	add(ja1);
	ja1.setText(petlist.get(0).getName());
	jb1.setBounds(117, 15, 45, 75);
	add(jb1);
	jb1.addActionListener(new ActionListener(){
		
		public void actionPerformed(ActionEvent e){
			int id=0;
			new PetData(id).setVisible(true);
			setVisible(false);
					
		}
		
	});
	
	ja2.setBounds(174, 15, 100, 75);
	add(ja2);
	ja2.setText(petlist.get(1).getName());
	jb2.setBounds(279, 15, 45, 75);
	add(jb2);
	jb2.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
			int id=1;
			new PetData(id).setVisible(true);
			setVisible(false);		
		}
		
	});
	
	ja3.setBounds(336, 15, 100, 75);
	add(ja3);
	ja3.setText(petlist.get(2).getName());
	jb3.setBounds(441, 15, 45, 75);
	add(jb3);
	jb3.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
			int id=2;
			new PetData(id).setVisible(true);
			setVisible(false);			
		}
		
	});
	
	ja4.setBounds(12, 105, 100, 75);
	add(ja4);
	ja4.setText(petlist.get(3).getName());
	jb4.setBounds(117, 105, 45, 75);
	add(jb4);
	jb4.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
			int id=3;
			new PetData(id).setVisible(true);
			setVisible(false);			
		}
		
	});
	
	ja5.setBounds(174, 105, 100, 75);
	add(ja5);
	ja5.setText(petlist.get(4).getName());
	jb5.setBounds(279, 105, 45, 75);
	add(jb5);
	jb5.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
			int id=4;
			new PetData(id).setVisible(true);
			setVisible(false);			
		}
		
	});
	
	ja6.setBounds(336, 105, 100, 75);
	add(ja6);
	ja6.setText(petlist.get(5).getName());
	jb6.setBounds(441, 105, 45, 75);
	add(jb6);
	jb6.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
			int id=5;
			new PetData(id).setVisible(true);
			setVisible(false);		
		}
		
	});
	
	ja7.setBounds(12, 195, 100, 75);
	add(ja7);
	ja7.setText(petlist.get(6).getName());
	jb7.setBounds(117, 195, 45, 75);
	add(jb7);
	jb7.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
			int id=6;
			new PetData(id).setVisible(true);
			setVisible(false);			
		}
		
	});
	
	ja8.setBounds(174, 195, 100, 75);
	add(ja8);
	ja8.setText(petlist.get(7).getName());
	jb8.setBounds(279, 195, 45, 75);
	add(jb8);
	jb8.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
			int id=7;
			new PetData(id).setVisible(true);
			setVisible(false);			
		}
		
	});
	
	ja9.setBounds(336, 195, 100, 75);
	add(ja9);
	ja9.setText(petlist.get(8).getName());
	jb9.setBounds(441, 195, 45, 75);
	add(jb9);
	jb9.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
			int id=8;
			new PetData(id).setVisible(true);
			setVisible(false);			
		}
		
	});
	
	ja10.setBounds(12, 285, 100, 75);
	add(ja10);
	ja10.setText(petlist.get(9).getName());
	jb10.setBounds(117, 285, 45, 75);
	add(jb10);
	jb10.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
			int id=9;
			new PetData(id).setVisible(true);
			setVisible(false);			
		}
		
	});
	
	ja11.setBounds(174, 285, 100, 75);
	add(ja11);
	ja11.setText(petlist.get(10).getName());
	jb11.setBounds(279, 285, 45, 75);
	add(jb11);
	jb11.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
			int id=10;
			new PetData(id).setVisible(true);
			setVisible(false);			
		}
		
	});
	
	ja12.setBounds(336, 285, 100, 75);
	add(ja12);
	ja12.setText(petlist.get(11).getName());
	jb12.setBounds(441, 285, 45, 75);
	add(jb12);
	jb12.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
			int id=11;
			new PetData(id).setVisible(true);
			setVisible(false);			
		}
		
	});
		
	back.setBounds(50, 375, 75, 50);
	add(back);
	back.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
			JOptionPane.showMessageDialog(null,"�ѳɹ��˳�");	
			setVisible(false);
		}
	});
	}	
	//��ȡ�����б�
	//public ArrayList<Pet> getPetList(){
		//return petlist;
///	}
	
/*
	//��ȡ���ﳵ��С���б�
		public int getCartSize(){
			return cartlist.size();
		}
		
		public ArrayList<Cart> getCartList(){
			return cartlist;
		}
		
		//���ﳵ����
		public String getShopList(){
			String data="";
			//����Ʒ���ӽ����ﳵ����ʾ
			for(int i=0;i<cartlist.size();i++){
				data +=i+"  "+display(petlist.get(i).getId())+"\n";
				System.out.println("һ��ѡ����"+cartlist.size()+"����Ʒ");
			}
			return data;
		}
		
		public int getShopSum(){
			int num=cartlist.size();
			return num;
			
		}
		
		public String display(int i){
			String data=petlist.get(i).getName();
			return data;
		}
	*/
	
	
	
	
	
	
	

	
	
	
}
