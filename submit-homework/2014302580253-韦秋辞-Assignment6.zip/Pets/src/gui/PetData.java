package gui;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import pojo.Cart;
import pojo.Pet;
import reader.PetDataReader;

//�����ȡ�������������Ϣ
@SuppressWarnings({ "unused", "serial" })
public class PetData extends JFrame{
private JFrame jf=new JFrame("��ϸ��Ϣ");
private JButton back=new JButton("����");//���ذ�ť
private JButton pay=new JButton("����");//����ť
private JButton cart=new JButton("���ﳵ");//���빺�ﳵҳ��
//private BasePage bp=new BasePage();
private PetDataReader pdr=new PetDataReader();
private ArrayList<Pet> petlist=pdr.getList();//��ȡ�����б�
private ArrayList<Cart> cartlist=new ArrayList<Cart>();//�����嵥
private int petId;
private int num=0;


public int getId(){
	return petId;
}
public void setId(int id){
	this.petId=id;
}

public PetData(int id){
	this.petId = id;
	setDefaultCloseOperation(EXIT_ON_CLOSE);
	setBounds(100, 100, 500, 500);
	setBackground(Color.gray);
	setLayout(null);//�����ɱ༭

	
	JTextField name=new JTextField();//������ʾ����
	name.setBounds(150, 50, 300, 50);
	add(name);
	name.setText("���ƣ�"+petlist.get(id).getName());
	
	
	JTextField eat=new JTextField();
	eat.setBounds(150, 110, 300, 50);
	add(eat);
	eat.setText("��:"+petlist.get(id).getEat());
	
	JTextField drink=new JTextField();
	drink.setBounds(150, 170, 300, 50);
	add(drink);
	drink.setText("��"+petlist.get(id).getDrink());
	
	JTextField live=new JTextField();
	live.setBounds(150, 240, 300, 50);
	add(live);
	live.setText("��ס������"+petlist.get(id).getLive());
	
	JTextField hobby=new JTextField();
	hobby.setBounds(150, 300, 300, 50);
    add(hobby);
    hobby.setText("ϰ�ԣ�"+petlist.get(id).getHobby());
    
    JTextField price=new JTextField();
    price.setBounds(150, 360, 300, 50);
    add(price);
    price.setText("500");
       
    back.setBounds(100, 430, 75, 50);
    pay.setBounds(200, 430, 75, 50);
    cart.setBounds(300, 430, 75, 50);
    add(back);
    add(pay);
    add(cart);
    
    //��ť�����¼�
    back.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
			setVisible(false);
			new BasePage().setVisible(true);
		}
	});
    
    pay.addActionListener(new ActionListener(){
    	public void actionPerformed(ActionEvent e){
    		num++;//���Ӵ���
    		int i=petlist.get(petId).getId();
    		Cart c=new Cart(i,num);
    		cartlist.add(c);
    		JOptionPane.showMessageDialog(null,"�ѳɹ����ӹ��ﳵһ��");
    	}
    });
    
    cart.addActionListener(new ActionListener(){
    	public void actionPerformed(ActionEvent e){
    		setVisible(false);
    		new ShopCar(cartlist).setVisible(true);
    	}
    });
   
}







}
