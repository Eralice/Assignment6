package gui;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;

import pojo.Cart;
import pojo.Pet;
import reader.PetDataReader;


//���ﳵ����
@SuppressWarnings({ "serial" })
public class ShopCar extends JFrame {
//private JFrame jf=new JFrame("���ﳵ");
JTextArea content=new JTextArea();//��ʾ���ﳵ����
private JButton delete=new JButton("���");
private JButton buy=new JButton("����");
private JButton back=new JButton("����");//������ҳ��
private ArrayList<Cart> cartList=new ArrayList<Cart>();
private PetDataReader pdr=new PetDataReader();
private ArrayList<Pet> petlist=pdr.getList();
//private BasePage bp;
private int sum=0;//������
private int price=0;//�ܼ�

public ShopCar(ArrayList<Cart> cartlist){
	//bp=new BasePage();
	this.cartList = cartlist;
	setDefaultCloseOperation(EXIT_ON_CLOSE);
	setBounds(100, 100, 500, 500);
	setBackground(Color.gray);
	setLayout(null);//�����ɱ༭
	
	
	content.setBounds(25, 50, 250, 250);
	content.setText("�������Ʒ�ֱ��ǣ�"+"\n"+getShopList());
	add(content);
	
	delete.setBounds(25, 325, 75, 50);
	buy.setBounds(130, 325, 75, 50);
	back.setBounds(235, 325, 75, 50);
	add(delete);
	add(buy);
	add(back);
	
	//��ť����ʱ��
	
	//delete
	delete.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
			content.setText("û���κ���Ʒ");//��չ��ﳵ����
		}
	});
	
	//buy
	buy.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){//�Ƚ��н���
			//sum=bp.getShopSum();
			int i=cartList.size();
			int n=0;
			int j=0;
			while(n<i){				
			    j=j+cartList.get(n).getNumber();
				n++;				
			}
			sum=i*j;
			price=sum*500;			
			JOptionPane.showMessageDialog(null,"�ܹ�"+sum+"����Ʒ"+"\n"+"�ܼ�Ϊ��"+price+"Ԫ"+"\n"+"����ɹ���");				
		}
	});
	
	//back
	back.addActionListener(new ActionListener(){
		public void actionPerformed(ActionEvent e){
			setVisible(false);
			new BasePage().setVisible(true);
		}
	});
	
	
}

public String getShopList(){
	String data="";
	for(int i=0;i<cartList.size();i++){
		int id=cartList.get(i).getId();
		data +=i+"  "+petlist.get(id).getName()+"\n";
	}
	return data;
	
}


}
