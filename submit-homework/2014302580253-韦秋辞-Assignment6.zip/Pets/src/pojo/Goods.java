package pojo;

public class Goods {
	private int id;
	private Pet pet;
	private int number;
	private float price;
	private int inventory;//���
	
	public Goods(int id, Pet pet, int number,float price,int inventory){
		this.id=id;
		this.pet=pet;
		this.number=number;
		this.price=price;
		this.inventory=inventory;
	}
	
	public int getId(){
		return id;
	}
	
	public void setId(int id){
		this.id=id;
	}
	
	public Pet getPet(){
		return pet;
	}
	
	public void setPet(Pet pet){
		this.pet=pet;
	}
	
	public int getNumber(){
		return number;
	}
	
	public void setNumber(int number){
		this.number=number;
	}
	
	public float getPrice(){
		return price;
	}
	
	public void setPrice(float price){
		this.price=price;
	}
	
	public int getInventory(){
		return inventory;
	}
	
	public void setInventory(int inventory){
		this.inventory=inventory;
	}
	
}
