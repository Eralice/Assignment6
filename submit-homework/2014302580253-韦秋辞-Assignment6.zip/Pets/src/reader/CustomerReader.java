package reader;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import pojo.Customer;


public class CustomerReader {
	static Connection conn;
	private ArrayList<Customer> cuslist=new ArrayList<Customer>();

	private static Connection getConnection(){
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/my_schema","root","123456");
			return conn;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
			}
		}	
		
		public int inset(Customer c){
		String sql="insert into 2014302580253_customer(name,password,account,phone,email)values(?,?,?,?,?)";
		int i=0;
		try{
			conn = getConnection();
			PreparedStatement ps= conn.prepareStatement(sql);
			ps.setString(1, c.getName());
			ps.setString(2, c.getPassword());
			ps.setInt(3,c.getAccount());
			ps.setInt(4, c.getPhone());
			ps.setString(5, c.getEmail());
			i=ps.executeUpdate();
			ps.close();					
		}catch(SQLException e){
			e.printStackTrace();
		}
		return i;		
		}
		
		public ArrayList<Customer> getCusList(){
			String sql="select * from 2014302580253_customer";
		    PreparedStatement ps;
		    try{
		    	conn=getConnection();
			ps = (PreparedStatement)conn.prepareStatement(sql);
			ResultSet res=ps.executeQuery();
		    while(res.next()){
		    	String name=res.getString(2).toLowerCase();
		    	String password=res.getString(3).toLowerCase();
		    	int account=res.getInt(4);
		    	int phone=res.getInt(5);
		    	String email=res.getString(6).toLowerCase();
		    	Customer c=new Customer(name,password,account,phone,email);
		    	cuslist.add(c);
		    }
	           
			    } catch (SQLException e) {
			        e.printStackTrace();
			    }
			    return cuslist;
			}
		

	}	
		
		
		
		
		
		
		
		
		
		
		
		
		

