package reader;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;






import pojo.Pet;


//�������ݿ�


public class PetDataReader {
static Connection conn;
private static  ArrayList<Pet> petlist=new ArrayList<Pet>();

private static Connection getConnection(){
	try {
		Class.forName("com.mysql.jdbc.Driver");
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	try {
		conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/my_schema","root","123456");
		return conn;
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		return null;
	}	
}
//��ȡ��������
public ArrayList<Pet> getList() {
	getConnection();
	String sql="select * from 2014302580253_pet";//�����ݿ��pet�ж�ȡ����
	PreparedStatement ps;
	try{
	ps = conn.prepareStatement(sql);
    ResultSet res = ps.executeQuery();
    while(res.next()){    	
    	int id=res.getInt(1);
    	String name = res.getString(2).toLowerCase();
    	String eat = res.getString(3).toLowerCase();
    	String drink = res.getString(4).toLowerCase();
    	String live = res.getString(5).toLowerCase();
    	String hobby = res.getString(6).toLowerCase();
    	Pet pet=new Pet(id,name,eat,drink,live,hobby);   	
    	petlist.add(pet);
    }
	}catch (SQLException e) {
        e.printStackTrace();
    }
	
	return petlist;

}

}
